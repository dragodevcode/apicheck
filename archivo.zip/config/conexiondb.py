from pymongo import MongoClient


class conect:
    @classmethod
    def getDb(cls):
        db = MongoClient("mongodb+srv://melaravladimir18:gA8zFOs3h3zmNWrt@cluster0.klnrpzp.mongodb.net")
        return db.teamkimori