from fastapi import APIRouter, Body
from pydantic import BaseModel, Field


import ast
import subprocess



routerGate = APIRouter(
    prefix='/api/bot',
    tags=['gatectr'],

)



                
                
class gateDataCore(BaseModel):
    ccclv:str = Field(...)



class gateDataCoreGenExtra(BaseModel):
    ccclv:str = Field(...)
    apikey:str = Field(...)
    count:str = Field(...)

    
@routerGate.post('/cn_checker')
def coreGate(dataGate:gateDataCore = Body(...) ):
    
    datac = dataGate.ccclv

    
    try:
        cp =  subprocess.run(["python3","bnmx.py",datac],capture_output=True)
        
        
        print(cp)
        responsex =cp.stdout.decode()

        datax:dict = ast.literal_eval(str(responsex.strip()))
    except:
        
        datax =  {'msg':4,'ccx12':dataGate.ccclv,'contentCC':datac+" err conecct ",'ccResponse': "",'proxy':None,'datext': ""}#6

    return datax

