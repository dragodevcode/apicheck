import math
import random
import datetime
from tool.infocc import info

class coregen:
    __patron = '0123456789'

    def validCClxd(self,ccValid,validCount):
        validx = 0
        validy = 0
        verypt1 =0
        procesVAlid = False
        for test in range(0,validCount,2):
            valueTem = 0
            valueTem = int(ccValid[test])*2
            if valueTem >= 10:
                valueTem = str(valueTem)
                validx += int(valueTem[0:1]) + int(valueTem[1:2])

            elif valueTem <= 9:
                validx += valueTem
            
        for test2  in range(1,validCount,2):
            validy += int(ccValid[test2])
        verypt1 = validx + validy
        validprocess = str(verypt1 + int(ccValid[-1:]))

        if validprocess[-1:] == '0':
            procesVAlid = True
        return procesVAlid
        
    def rndg(self,ccxbin,cantidad):
        ccGen = list()
        CcgenEnd = list()
        contentx = ccxbin.replace(' ','')
        contentx = contentx.split('|')
        binx = contentx[0]
        infox = info()
        for intcc in range(0,int(cantidad)):
            for ccRamd in range(0,1000):
                ccnew = ""
                ccnew = self.rdncx(binx)
                tipo = binx[0:1]
                if tipo == '3':
                    validCCoun = 14
                else:
                    validCCoun = 15
                if self.validCClxd(ccnew,validCCoun):
                    ccGen.append(ccnew)
                    break
        for ccgenx in ccGen:
            cvx = ''
            if contentx[1] == 'rnd':
                m = str(random.randint(1,12))
                if len(m) == 1:
                    m = '0'+m
            else:
                m = infox.checkMoth(contentx[1],'xx')
            if contentx[2] == 'rnd':
                y = datetime.datetime.now().year
                y += random.randint(1,6)
            else:
                y = infox.checkYear(contentx[2],'xxxx')
                y = int(y)
            if contentx[3] == 'rnd':
                tipo = binx[0:1]
                if tipo == '3':
                    cvx = math.floor(random.random()*(9998 - 1102 + 1))+ 1102
                else:
                    cvx = math.floor(random.random() *(998 - 112 + 1)) + 112  
            else:
                cvx = contentx[3]

            CcgenEnd.append(ccgenx+'|'+m+'|'+str(y)+'|'+str(cvx))
        return CcgenEnd
    def rdncx(self,binx):
        newCCValorTEmp = '' 
        for xrandbin in binx:
            if xrandbin in 'x':
                newCCValorTEmp += self.mids(self.__patron,math.floor(random.random()*(len(self.__patron) - 1) + 1),1) 
            else:
                newCCValorTEmp += xrandbin
        return newCCValorTEmp
    def mids(self,patron,n,n2):
        if n2 == None or n2 == "":
            n2 = len(patron)
        n *= 1
        n2 *=1
        if n < 0:
            n+=1
        numb = patron[n-1:n-1+n2]
        return numb
    








