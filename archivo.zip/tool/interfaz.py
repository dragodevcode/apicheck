import sys
from colorama import init, Fore
import os

class presentacion:
    def __clear(self):
        if os.name == "nt":
            os.system("cls")
        else:
            os.system("clear")

        banner = """
   __  __       _ _   _             _       ____             ____ _     _    
  |  \/  |_   _| | |_(_) __ _  __ _| |_ ___|  _ \ _ __ ___  / ___| |__ | | __
  | |\/| | | | | | __| |/ _` |/ _` | __/ _ \ |_) | '__/ _ \| |   | '_ \| |/ /
  | |  | | |_| | | |_| | (_| | (_| | ||  __/  __/| | | (_) | |___| | | |   < 
  |_|  |_|\__,_|_|\__|_|\__, |\__,_|\__\___|_|   |_|  \___/ \____|_| |_|_|\_\\
                        |___/
        """
        print(Fore.RED + banner)

    def initGen(self):
        msg = """
           Bienvenido ala version beta de esta tool. - V 2.0.0
#######################################################################
Incluye:
 #- Bot BBva


Nota: importante que el bin este completo con sus respectivos 16 o 15
                                                    Autor lorusdev
                                                    
        """
        self.__clear()
        print(Fore.CYAN + msg)

    def initOptionChecker(self):
        msg = """
           Bienvenido ala version beta de esta tool. - V 1.0.0
#######################################################################

            Selecione el uso del checker a utilizar
                                                    Autor eduarwd
                                                         by TeamEzpyna 
                                                    
        """
        self.__clear()
        print(Fore.CYAN + msg)

    def initCardsas(self):
        msg = """
           Bienvenido ala version beta de esta tool. - V 1.0.0
#######################################################################
Incluye:
 #- Gate Genedaras and cards
Instrucciones
 ** Para ocupar el Checker el formato de la tarjeta es de esta forma: 

                                             4482330060823762|01|2021|324
                                             4482330060823762|1|21|324

Nota: Revise bien el formato para no cometer algun error en su test
                                                    Autor eduarwd
                                                         by TeamEzpyna 
                                                    
        """
        self.__clear()
        print(Fore.CYAN + msg)

    def initChecker(self):
        msg = """
                         CHECKER CLI. - V 1.0.2  
#######################################################################
Incluye:
 #- AutoScraper //pendiente
 #- Gate Anubis
Instrucciones
 ** Pendiente
                                                    Autor eduarwd
                                                         by TeamEzpyna 
                                                    
        """
        self.__clear()
        print(Fore.CYAN + msg)
    def ConfigGate(self,nameGAte):

        msg = f"""

                          {nameGAte} 
#######################################################################
Instrucciones
 # Este gate ocupa credenciales
 # Al ocuparlo por primera vez, coloque las credenciales
 # si existe registro de crenciales coloque 1 para renovar, de lo
   contrario presione cualquier letra para seguir
                                                    Autor eduarwd
                                                         by TeamEzpyna 
                                                    
        """
        self.__clear()
        print(Fore.CYAN + msg)
    def ConfigChecker(self,nameEvent):

        msg = f"""

                          {nameEvent} 
#######################################################################
Instrucciones
# En El block de notas
                                                    Autor lorusdev
                                                         
                                                    
        """
        self.__clear()
        print(Fore.CYAN + msg)
    def selectNameGate(self,nameEvent):

        msg = f"""

                          {nameEvent} 
#######################################################################
Instrucciones
# selenione el numero de gate que aparece en la lista que corresponda

                                                    Autor eduarwd
                                                         by TeamEzpyna 
                                                    
        """
        self.__clear()
        print(Fore.CYAN + msg)
    def ResultxGate(self,nameGAte,resultxxx,total,ccCount):
        resultDie = ""
        resultLive = ""
        countLive = 0
        for resultados in resultxxx:
            if resultados['code'] == 'live':
                resultLive += "Live ==> "+resultados['cc']+"\n"
                countLive += 1
            else:
                resultDie += "Dead ==> "+resultados['cc']+"\n"
        msg = f"""
                          {nameGAte} - Procesando... ({total}/{ccCount})
#######################################################################
DEAD

{resultDie}
LIVE {str(countLive)}

{resultLive}


                                                    Autor eduarwd
                                                         by TeamEzpyna 
                                                    
        """
        self.__clear()
        print(Fore.CYAN + msg)

